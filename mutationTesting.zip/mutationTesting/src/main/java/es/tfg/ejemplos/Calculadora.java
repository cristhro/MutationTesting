package es.tfg.ejemplos;

public class Calculadora {
    public int suma(int operando1, int operando2){
        return operando1 + operando2;
    }

    public int resta(int operando1, int operando2){
        return operando1 - operando2;
    }

    public int multiplica(int operando1, int operando2){
        return operando1 / operando2;
    }

    public int divide(int operando1, int operando2){
        return operando1 / operando2;
    }
}
