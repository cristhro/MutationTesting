package es.tfg.ejemplos;

public class FuncionSimple {
	public int f1(int i){
        if(i==1) {
           return 1;
        }else{ 
           return 0; 
        }
    }
}
