package es.tfg.ejemplos;

public class Condicional {

    public int esMenor(int a, int b){
        if (a < b){
            return 1;
        }
          return  0;
    }
}
